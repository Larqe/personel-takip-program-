﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonelTakip
{
    public partial class RaporlamaForm : Form
    {
        string connectionString = "Data Source=.;Initial Catalog=personeltakip;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        SqlConnection connection;

        int rolId;
        string KullaniciAdi;
        public RaporlamaForm(int rolId, string KullaniciAdi)
        {
            InitializeComponent();
            this.rolId = rolId;
            this.KullaniciAdi = KullaniciAdi;
            connection = new SqlConnection(connectionString);
        }

        private void btnRaporla_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Personel WHERE Maas >= @Maas";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Maas", Convert.ToDecimal(txtMaasFiltre.Text));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dgvRapor.DataSource = table;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AnaForm anaForm = new AnaForm(rolId, KullaniciAdi);
            anaForm.Show();
            this.Close();
        }

        private void RaporlamaForm_Load(object sender, EventArgs e)
        {

        }
    }
}
