﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PersonelTakip
{
    public partial class LoginForm : Form
    {
        string connectionString = "Data Source=.;Initial Catalog=personeltakip;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";
        SqlConnection connection;

        public LoginForm()
        {
            InitializeComponent();
            connection = new SqlConnection(connectionString);
        }

        

        private void btnGiris_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Kullanici WHERE KullaniciAdi = @KullaniciAdi AND Sifre = @Sifre";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@KullaniciAdi", txtKullaniciAdi.Text);
                command.Parameters.AddWithValue("@Sifre", txtSifre.Text);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    int rolId = reader.GetInt32(reader.GetOrdinal("RolId"));
                    string KullaniciAdi = reader.GetString(reader.GetOrdinal("KullaniciAdi"));
                    AnaForm anaForm = new AnaForm(rolId, KullaniciAdi);
                    this.Hide();
                    anaForm.Show();
                }
                else
                {
                    MessageBox.Show("Kullanıcı adı veya şifre hatalı!");
                }
                connection.Close();
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
