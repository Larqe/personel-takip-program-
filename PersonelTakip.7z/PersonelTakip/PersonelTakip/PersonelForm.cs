﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonelTakip
{
    public partial class PersonelForm : Form
    {
        string connectionString = "Data Source=.;Initial Catalog=personeltakip;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        SqlConnection connection;

        int rolId;
        string KullaniciAdi;
        public PersonelForm(int rolId, string KullaniciAdi)
        {
            InitializeComponent();
            connection = new SqlConnection(connectionString);
            this.rolId = rolId;
            this.KullaniciAdi = KullaniciAdi;
            Listele();
        }

        private void temizlegör()
        {
            txtAd.Text="";
            txtSoyad.Text="";
            txtMaas.Text="";
            txtPozisyon.Text="";
            txtAd.Enabled=true;
            txtSoyad.Enabled=true;
            txtMaas.Enabled=true;
            txtPozisyon.Enabled=true;
            btnEkle.Enabled=true;
            btnSil.Enabled=true;
            btnGüncelle.Enabled=true;
        }        
        private void temizlegizle()
        {
            txtAd.Text="";
            txtSoyad.Text="";
            txtMaas.Text="";
            txtPozisyon.Text="";
            txtAd.Enabled=false;
            txtSoyad.Enabled=false;
            txtMaas.Enabled=false;
            txtPozisyon.Enabled=false;
            btnEkle.Enabled=false;
            btnSil.Enabled=false;
            btnGüncelle.Enabled=false;
        }

        private void Listele()
        {
            string query = "SELECT * FROM Personel";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dgvPersonel.DataSource = table;
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Personel (Ad, Soyad, Pozisyon, Maas) VALUES (@Ad, @Soyad, @Pozisyon, @Maas)";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Ad", txtAd.Text);
                command.Parameters.AddWithValue("@Soyad", txtSoyad.Text);
                command.Parameters.AddWithValue("@Pozisyon", txtPozisyon.Text);
                command.Parameters.AddWithValue("@Maas", Convert.ToDecimal(txtMaas.Text));

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                temizlegizle();
            }
            Listele();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Personel SET Ad = @Ad, Soyad = @Soyad, Pozisyon = @Pozisyon, Maas = @Maas WHERE Id = @Id";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Ad", txtAd.Text);
                command.Parameters.AddWithValue("@Soyad", txtSoyad.Text);
                command.Parameters.AddWithValue("@Pozisyon", txtPozisyon.Text);
                command.Parameters.AddWithValue("@Maas", Convert.ToDecimal(txtMaas.Text));
                command.Parameters.AddWithValue("@Id", Convert.ToInt32(dgvPersonel.SelectedRows[0].Cells[0].Value));

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                temizlegizle();
            }
            Listele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dgvPersonel.Rows.Count == 1)
            {
                MessageBox.Show("Bu, son kalan kayıttır. Bu kaydı silmek istediğinizden emin misiniz?", "Uyarı", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                return;
            }

            if (dgvPersonel.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen silmek için bir satır seçin.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var result = MessageBox.Show("Bu kaydı silmek istediğinize emin misiniz?", "Silme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                string query = "DELETE FROM Personel WHERE Id = @Id";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", Convert.ToInt32(dgvPersonel.SelectedRows[0].Cells["Id"].Value));  // 'Id' sütununun adını kontrol edin

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    temizlegizle();
                }
                Listele();
            }
        }


        private void dgvPersonel_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            temizlegizle();
            btnSil.Enabled = true;
            btnyeni.Enabled = true;
            btnYenile.Enabled = true;
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvPersonel.Rows[e.RowIndex];

                txtAd.Text = row.Cells["Ad"].Value.ToString();
                txtSoyad.Text = row.Cells["Soyad"].Value.ToString();
                txtPozisyon.Text = row.Cells["Pozisyon"].Value.ToString();
                txtMaas.Text = row.Cells["Maas"].Value.ToString();
            }
            else
                MessageBox.Show("Veri Yok Dost");
        }

        private void btnyeni_Click(object sender, EventArgs e)
        {
            temizlegör();
            btnGüncelle.Enabled = false;
            btnSil.Enabled = false;
        }

        private void btnYenile_Click(object sender, EventArgs e)
        {
            btnEkle.Enabled = false;
            btnSil.Enabled=false;
            btnGüncelle.Enabled = true;
            txtAd.Enabled = true;
            txtSoyad.Enabled = true;
            txtMaas.Enabled = true;
            txtPozisyon.Enabled = true;
            btnYenile.Enabled = false;
            btnyeni.Enabled = false;
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            AnaForm anaForm = new AnaForm(rolId, KullaniciAdi);
            anaForm.Show();
            this.Close();
        }

        private void PersonelForm_Load(object sender, EventArgs e)
        {

        }
    }

}
