﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonelTakip
{
    public partial class KullaniciEkleForm : Form
    {
        string connectionString = "Data Source=.;Initial Catalog=personeltakip;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        SqlConnection connection;

        int rolId;
        string KullaniciAdi;

        public KullaniciEkleForm(int rolId, string KullaniciAdi)
        {
            InitializeComponent();
            this.rolId = rolId;
            this.KullaniciAdi = KullaniciAdi;
            connection = new SqlConnection(connectionString);
            Listele();
        }

        private void Listele()
        {
            try
            {
                // Veritabanı bağlantısının tanımlı ve açık olduğundan emin olun
                if (connection == null)
                {
                    throw new InvalidOperationException("Veritabanı bağlantısı tanımlı değil.");
                }

                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                // Sorguyu tanımla
                string query = "SELECT Kullanici.Id, Kullanici.KullaniciAdi, Kullanici.Sifre, Rol.RolAdi FROM Kullanici INNER JOIN Rol ON Kullanici.RolId = Rol.Id";


                // Adapter ve DataTable oluştur
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable table = new DataTable();

                // DataTable'ı doldur
                adapter.Fill(table);

                // DataGridView'e veriyi ata
                dgvKullanici.DataSource = table;

                // Tablo satır sayısını kontrol et (örneğin debugging için)
                MessageBox.Show("Toplam kayıt sayısı: " + table.Rows.Count.ToString());
            }
            catch (Exception ex)
            {
                // Hata durumunda mesaj göster
                MessageBox.Show("Veriler yüklenirken bir hata oluştu: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }



        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (cmbRol.SelectedIndex == -1)
            {
                MessageBox.Show("Lütfen bir rol seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // ComboBox'tan seçilen rolün ID'sini alıyoruz
            int selectedRoleId = Convert.ToInt32(cmbRol.SelectedValue);

            string query = "INSERT INTO Kullanici (KullaniciAdi, Sifre, RolId) VALUES (@KullaniciAdi, @Sifre, @RolId)";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@KullaniciAdi", txtKullaniciAdi.Text);
                command.Parameters.AddWithValue("@Sifre", txtSifre.Text);
                command.Parameters.AddWithValue("@RolId", selectedRoleId);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            MessageBox.Show("Kullanıcı başarıyla eklendi.");
            Listele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dgvKullanici.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen silmek istediğiniz kullanıcıyı seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedId = Convert.ToInt32(dgvKullanici.SelectedRows[0].Cells[0].Value);

            string query = "DELETE FROM Kullanici WHERE Id = @Id";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Id", selectedId);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            MessageBox.Show("Kullanıcı başarıyla silindi.");
            Listele();
        }


        private void KullaniciEkleForm_Load(object sender, EventArgs e)
        {
            RolleriYukle();
        }

        private void RolleriYukle()
        {
            string query = "SELECT Id, RolAdi FROM Rol";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DataTable table = new DataTable();
            adapter.Fill(table);

            cmbRol.DisplayMember = "RolAdi";
            cmbRol.ValueMember = "Id"; 
            cmbRol.DataSource = table;
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            AnaForm anaform = new AnaForm(rolId, KullaniciAdi);
            anaform.Show();
            this.Close();
        }

        private void dgvKullanici_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvKullanici.Rows[e.RowIndex];

                txtKullaniciAdi.Text = row.Cells["KullaniciAdi"].Value.ToString();
                txtSifre.Text = row.Cells["Sifre"].Value.ToString();
                cmbRol.Text = row.Cells["RolAdi"].Value.ToString();
            }
            else
                MessageBox.Show("Veri Yok Dost");
        }
    }

}
