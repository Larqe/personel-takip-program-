﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonelTakip
{
    public partial class IzinTalepForm : Form
    {
        string connectionString = "Data Source=.;Initial Catalog=personeltakip;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        SqlConnection connection;

        int rolId;
        string KullaniciAdi;
        public IzinTalepForm(int rolId, string KullaniciAdi)
        {
            InitializeComponent();
            connection = new SqlConnection(connectionString);
            this.rolId = rolId;
            this.KullaniciAdi = KullaniciAdi;
            YetkiKontrol();
            Listele();
            PersonelleriGetir();
        }

        private void YetkiKontrol()
        {
            if (rolId == 2)
            {
                btnOnayla.Enabled = false;
                btnReddet.Enabled = false;
            }            
            if (rolId == 1)
            {
                btnTalepEkle.Enabled = false;
            }
            
        }

        private void Listele()
        {
            string query = "SELECT Izinler.Id, CONCAT(Personel.Ad, ' ', Personel.Soyad) AS PersonelAdSoyad, BaslangicTarihi, BitisTarihi, IzinTuru, Durum FROM Izinler INNER JOIN Personel ON Izinler.PersonelId = Personel.Id";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dgvIzinler.DataSource = table;
        }

        private void PersonelleriGetir()
        {
            string query = "SELECT Id, CONCAT(Ad, ' ', Soyad) AS AdSoyad FROM Personel";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            cmbPersonel.DataSource = table;
            cmbPersonel.DisplayMember = "AdSoyad";
            cmbPersonel.ValueMember = "Id";
        }

        private void btnTalepEkle_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Izinler (PersonelId, BaslangicTarihi, BitisTarihi, IzinTuru, Durum) VALUES (@PersonelId, @BaslangicTarihi, @BitisTarihi, @IzinTuru, @Durum)";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@PersonelId", Convert.ToInt32(cmbPersonel.SelectedValue));
                command.Parameters.AddWithValue("@BaslangicTarihi", dtpBaslangicTarihi.Value);
                command.Parameters.AddWithValue("@BitisTarihi", dtpBitisTarihi.Value);
                command.Parameters.AddWithValue("@IzinTuru", cmbIzinTuru.SelectedItem.ToString());
                command.Parameters.AddWithValue("@Durum", "Bekliyor");

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            Listele();
        }

        private void btnOnayla_Click(object sender, EventArgs e)
        {
            if (dgvIzinler.SelectedRows.Count > 0)
            {
                string query = "UPDATE Izinler SET Durum = @Durum WHERE Id = @Id";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Durum", "Onaylandı");
                    command.Parameters.AddWithValue("@Id", Convert.ToInt32(dgvIzinler.SelectedRows[0].Cells["Id"].Value));

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
                Listele();
            }
            else
            {
                MessageBox.Show("Lütfen bir izin talebi seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnReddet_Click(object sender, EventArgs e)
        {
            if (dgvIzinler.SelectedRows.Count > 0)
            {
                string query = "UPDATE Izinler SET Durum = @Durum WHERE Id = @Id";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Durum", "Reddedildi");
                    command.Parameters.AddWithValue("@Id", Convert.ToInt32(dgvIzinler.SelectedRows[0].Cells["Id"].Value));

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
                Listele();
            }
            else
            {
                MessageBox.Show("Lütfen bir izin talebi seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AnaForm anaForm = new AnaForm(rolId,KullaniciAdi);
            anaForm.Show();
            this.Close();
        }

        private void IzinTalepForm_Load(object sender, EventArgs e)
        {
            cmbIzinTuru.Items.Add("Yıllık İzin"); 
            cmbIzinTuru.Items.Add("Hastalık İzni"); 
            cmbIzinTuru.Items.Add("Doğum İzni"); 
            cmbIzinTuru.Items.Add("Eğitim İzni"); 
            cmbIzinTuru.Items.Add("Özel İzin"); 
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dgvIzinler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvIzinler.Rows[e.RowIndex];

                cmbPersonel.SelectedItem = row.Cells["PersonelAdSoyad"].Value.ToString();
                cmbIzinTuru.SelectedItem = row.Cells["IzinTuru"].Value.ToString(); // İzin türünü seçili hale getir
                dtpBaslangicTarihi.Value = Convert.ToDateTime(row.Cells["BaslangicTarihi"].Value); // Başlangıç tarihini ayarla
                dtpBitisTarihi.Value = Convert.ToDateTime(row.Cells["BitisTarihi"].Value); // Bitiş tarihini ayarla
            }
            else
            {
                MessageBox.Show("Geçerli bir satır seçilmedi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

    }

}
