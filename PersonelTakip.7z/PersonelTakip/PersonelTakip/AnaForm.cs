﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonelTakip
{
    public partial class AnaForm : Form
    {

        int rolId;
        string KullaniciAdi;

        public AnaForm(int rolId, string KullaniciAdi)
        {
            InitializeComponent();
            this.rolId = rolId;
            this.KullaniciAdi = KullaniciAdi;
            merhabagöster();
            YetkiKontrol();
        }

        private void YetkiKontrol()
        {
            if (rolId == 2)
            {
                btnPersonel.Enabled = false;
                btnYeniÜye.Enabled = false;
            }
        }

        private void AnaForm_Load(object sender, EventArgs e)
        {
            merhabagöster();
        }

        private void merhabagöster() {
            label4.Visible = true;
            label4.Text = "Merhaba, " + KullaniciAdi;
        }

        private void btnPersonel_Click(object sender, EventArgs e)
        {
            PersonelForm personelForm = new PersonelForm(rolId, KullaniciAdi);
               personelForm.Show();
            this.Close();
        }

        private void btnRaporlama_Click(object sender, EventArgs e)
        {
            RaporlamaForm raporlamaForm = new RaporlamaForm(rolId, KullaniciAdi);
            raporlamaForm.Show();
            this.Close();
        }

        private void btnYeniÜye_Click(object sender, EventArgs e)
        {
            KullaniciEkleForm kullaniciEkle = new KullaniciEkleForm(rolId, KullaniciAdi);
            kullaniciEkle.Show();
            this.Close();
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void btnİzinler_Click(object sender, EventArgs e)
        {
            IzinTalepForm ızinTalep = new IzinTalepForm(rolId, KullaniciAdi);
            ızinTalep.Show();
            this.Close();
        }
    }
}
